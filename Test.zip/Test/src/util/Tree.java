package util;

import java.util.List;

public class Tree<T> {

    T node;
    T parentNode;
    List<T> childrens;
}
