package service;

import dao.CategoryDAO;
import dao.ProductDAO;
import domain.Category;
import domain.Product;

import java.util.ArrayList;
import java.util.List;

public class ProductService {

    public List<Product> getAllProductsByCategoryId(int categoryId) {
        //TODO: There is no child reference, hence need to change data structure
        return null;
    }

    /*
    Given a product id, return the category path
    @productId Id of the product in question
    @returns List of category names from bottom to top.
    //TV, Electronic, Root
     */
    public List<String> getCategoryPathByProductId(int productId) {

        ProductDAO dao = new ProductDAO();
        Product product = dao.getProduct(productId);
        List<String> categoryNames = new ArrayList<>();
        int categoryId = product.getCategoryId();
        do {
            CategoryDAO categoryDAO = new CategoryDAO();
            Category category = categoryDAO.getCategoryById(categoryId);
            categoryNames.add(category.getName());
            categoryId = category.getParentCategoryId();

        } while (categoryId != 0);
        return categoryNames;
    }
}
