package domain;

public class Product {

    private static int seqNumber = 1;
    private int productId;
    private String name;
    private String description;
    private float pricing;
    private int categoryId;


    public Product(String name, String description, float pricing, int categoryId) {
        this.name = name;
        this.description = description;
        this.pricing = pricing;
        this.categoryId = categoryId;
        this.productId = getNextSeqCatNumber();
    }
    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getPricing() {
        return pricing;
    }

    public void setPricing(float pricing) {
        this.pricing = pricing;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    private synchronized int getNextSeqCatNumber() {
        return seqNumber++;
    }
}
