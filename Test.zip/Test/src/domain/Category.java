package domain;

public class Category {

    private static int seqNumber = 1;

    private int categoryId;
    private String name;
    private int parentCategoryId;

    public Category(String name, int parentCategoryId) {
        this.name = name;
        this.parentCategoryId = parentCategoryId;
        this.categoryId = getNextSeqCatNumber();
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getParentCategoryId() {
        return parentCategoryId;
    }

    public void setParentCategoryId(int parentCategoryId) {
        this.parentCategoryId = parentCategoryId;
    }

    private synchronized int getNextSeqCatNumber() {
        return seqNumber++;
    }


}
