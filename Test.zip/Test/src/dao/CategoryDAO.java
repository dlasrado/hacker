package dao;

import domain.Category;
import exceptions.CategoryNotFoundException;

import java.util.TreeMap;

public class CategoryDAO {

    //All the category data will be persisted in this TreeMap?
    static TreeMap<Integer, Category> categoryTree = new TreeMap<>();

    public int addCategory(String name, int parentCategoryId) {

        Category category = new Category(name, parentCategoryId);
        categoryTree.put(category.getCategoryId(), category);
        return category.getCategoryId();
    }

    public void updateCategory(int categoryId, String newName) {
        Category category = categoryTree.get(categoryId);
        if (category == null) {
            throw new CategoryNotFoundException("The category with id "+ categoryId+" is not found");
        }
        category.setName(newName);
    }

    public void moveCategory(int categoryId, int newParentId) {
        Category category = categoryTree.get(categoryId);
        if (category == null) {
            throw new CategoryNotFoundException("The category with id "+ categoryId+" is not found");
        }
        //Check for parent categry as well.
        Category parentCategory = categoryTree.get(newParentId);
        if (parentCategory == null) {
            throw new CategoryNotFoundException("The parent category with id "+ parentCategory+" is not found");
        }
        category.setParentCategoryId(newParentId);
    }

    //Delete category is required? If so what is the behaviour for child categories?
    //Not supported.
    /*public Category removeCategory(int categoryId) {
        Category category = categoryTree.remove(categoryId);
        if (category == null) {
            throw new CategoryNotFoundException("The category with id "+ categoryId+" is not found");
        }

        //TODO: Behaviour unclear for child
        return category;
    }*/

    public Category getCategoryById(int categoryId) {

        Category category = categoryTree.get(categoryId);
        if (category == null) {
            throw new CategoryNotFoundException("The category with id "+ categoryId+" is not found");
        }
        return category;
    }

    /*
    Get the parent category
     */
    public Category getParentCategory(int categoryId) {
        Category category = categoryTree.get(categoryId);
        if (category == null) {
            throw new CategoryNotFoundException("The category with id "+ categoryId+" is not found");
        }
        return categoryTree.get(category.getParentCategoryId());
    }

}
