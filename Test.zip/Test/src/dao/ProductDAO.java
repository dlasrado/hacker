package dao;

import domain.Category;
import domain.Product;
import exceptions.ProductNotFoundException;

import java.util.HashMap;
import java.util.Map;

public class ProductDAO {

    static Map<Integer, Product> products = new HashMap<>();

    /*
    Add a product in a given product category
    @name name of the product
    @desc A brief description for the product
    @pricing The list price for the product
    @categoryId Id of the category to which the product will belong to

    @return ProductId
     */
    public int addProduct(String name, String desc, float pricing, int categoryId) {
        Product product = new Product(name, desc, pricing, categoryId);
        products.put(product.getProductId(), product);
        return product.getProductId();

    }

    /*
    Update a product. Updates can be made to name, desc, price or category
    @name name of the product
    @desc A brief description for the product
    @pricing The list price for the product
    @categoryId Id of the category to which the product will belong to
     */
    public void updateProduct(int productId, String name, String desc, float pricing, int categoryId) {
        Product product = products.get(productId);

        if (product == null) {
            throw new ProductNotFoundException("Product with Id "+ productId +" is not found");
        }
        product.setName(name);
        product.setDescription(desc);
        product.setPricing(pricing);
        product.setCategoryId(categoryId);


    }

    /*
    Given a product id, returns the category object
     */
    public Category getProductCategory(int productId) {
        Product product = products.get(productId);
        if (product == null) {
            throw new ProductNotFoundException("Product with Id "+ productId +" is not found");
        }
        return new CategoryDAO().getCategoryById(product.getCategoryId());
    }

    /*
    Given the product id, return the product object
     */
    public Product getProduct(int productId) {
        Product product = products.get(productId);
        if (product == null) {
            throw new ProductNotFoundException("Product with Id "+ productId +" is not found");
        }
        return product;
    }

}
