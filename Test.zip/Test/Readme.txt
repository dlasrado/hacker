domain.Category
    ->Sub category
        -> domain.Product
        -> Sub domain.Category
            -> domain.Product

domain.Product (productId, name, description, pricing, categoryId)
domain.Category (categoryId, name, parentCategoryId)

Req:
    1. Given a category, get all products af this and all child categories
    2. Given a product, get the category path

